package com.fujiang.cainiao;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import java.lang.ref.WeakReference;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 菜鸟裹酱 · 进程内自动点击
 * 装官方原版菜鸟，LSPosed 启用本模块，作用域勾 com.cainiao.wireless
 */
public class MainHook implements IXposedHookLoadPackage {

    static final String TAG = "[FJ-CN] ";
    static final String PKG = "com.cainiao.wireless";

    /** 任务按钮可能出现的文字，新版改这里 */
    static final String[] BTN_WORDS = {
            "去完成", "去逛逛", "去浏览", "立即领取", "领取", "做任务", "看视频", "去观看"
    };

    /** 每轮间隔（毫秒） */
    static final long INTERVAL = 3000;

    /** 单次上限定，防跑飞 */
    static final int MAX_CLICK = 60;

    /** 两次点击之间，同一个控件的最短间隔（毫秒），防连点 */
    static final long SAME_VIEW_GAP = 8000;

    static WeakReference<Activity> sAct = new WeakReference<>(null);
    static Handler sHandler;
    static int sClicked = 0;
    static boolean sRunning = false;
    static View sLastView = null;
    static long sLastTime = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        log("模块已注入进程");

        sHandler = new Handler(Looper.getMainLooper());

        // 1. 跟踪前台页面
        XposedHelpers.findAndHookMethod("android.app.Activity", lp.classLoader,
                "onResume", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam p) {
                        Activity a = (Activity) p.thisObject;
                        if (a == null) return;
                        sAct = new WeakReference<>(a);
                        String n = a.getClass().getSimpleName();
                        log("前台页面: " + n);
                        if (n.toLowerCase().contains("task")
                                || n.toLowerCase().contains("guojiang")
                                || n.toLowerCase().contains("reward")) {
                            start();
                        }
                    }
                });

        // 2. 观察谁在调 performClick（对照用）
        XposedHelpers.findAndHookMethod("android.view.View", lp.classLoader,
                "performClick", new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam p) {
                        View v = (View) p.thisObject;
                        log("performClick <- " + v.getClass().getName());
                    }
                });
    }

    // ---------------- 主循环 ----------------

    static void start() {
        if (sRunning) return;
        sRunning = true;
        sClicked = 0;
        log("=== 开始轮询 ===");
        step();
    }

    static void step() {
        if (sHandler == null) return;
        sHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    tick();
                } catch (Throwable t) {
                    log("轮询异常: " + t);
                }
                if (sRunning && sClicked < MAX_CLICK) {
                    step();
                } else {
                    sRunning = false;
                    log("=== 收工，共点 " + sClicked + " 次 ===");
                }
            }
        }, INTERVAL);
    }

    static void tick() {
        Activity act = sAct.get();
        if (act == null || act.isFinishing()) {
            log("当前无可用页面");
            return;
        }

        View root = act.getWindow() == null ? null : act.getWindow().getDecorView();
        if (root == null) return;

        View textView = findBtn(root);
        if (textView == null) {
            log("本页没找到可点的按钮: " + act.getClass().getSimpleName());
            return;
        }

        View clickable = climb(textView);

        // 同一个控件短时间内不重复点
        long now = System.currentTimeMillis();
        if (clickable == sLastView && now - sLastTime < SAME_VIEW_GAP) {
            log("同控件冷却中，跳过");
            return;
        }

        String label = "";
        try { label = ((TextView) textView).getText().toString(); } catch (Throwable ignored) {}

        boolean ok = clickable.performClick();
        sClicked++;
        sLastView = clickable;
        sLastTime = now;

        log("点击 [" + label + "] 返回=" + ok
                + " 控件=" + clickable.getClass().getSimpleName()
                + " 累计=" + sClicked);
    }

    // ---------------- View 工具 ----------------

    static View findBtn(View root) {
        if (root == null || root.getVisibility() != View.VISIBLE) return null;

        if (root instanceof TextView) {
            CharSequence cs = ((TextView) root).getText();
            if (cs != null) {
                String t = cs.toString();
                if (t.length() > 0 && t.length() < 20) {
                    for (String k : BTN_WORDS) {
                        if (t.contains(k)) return root;
                    }
                }
            }
        }

        if (root instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) {
                View v = findBtn(g.getChildAt(i));
                if (v != null) return v;
            }
        }
        return null;
    }

    static View climb(View v) {
        View cur = v;
        for (int i = 0; i < 8 && cur != null; i++) {
            if (cur.isClickable()) return cur;
            ViewParent p = cur.getParent();
            if (!(p instanceof View)) break;
            cur = (View) p;
        }
        return v;
    }

    static void log(String s) {
        XposedBridge.log(TAG + s);
    }
}
