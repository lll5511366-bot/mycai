package de.robv.android.xposed;

import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 编译用的桩（stub）。运行时由 Xposed/LSPosed 框架提供真正的实现。
 * 因为框架的类在 BootClassLoader 里，优先于本模块的同名类，
 * 所以这里永远不会被执行，只是让编译器能过。
 */
public interface IXposedHookLoadPackage {
    void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable;
}
