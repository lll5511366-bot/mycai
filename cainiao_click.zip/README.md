# 菜鸟自动点击 · LSPosed 模块

装在**官方原版菜鸟**上，进程内调用 `View.performClick()` 自动点任务按钮。
不换签名、不改包、不用无障碍。

---

## 目录结构

```
cainiao_click/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── .github/workflows/build.yml      ← 云端自动出 APK
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/xposed_init
        ├── java/com/fujiang/cainiao/MainHook.java
        └── res/values/arrays.xml
```

---

## 方式一：Android Studio（推荐）

1. Android Studio → **Open** → 选这个文件夹 `cainiao_click`
2. 等 Gradle 同步完（会下载 AGP 和 xposed api）
3. 菜单 **Build → Build Bundle(s)/APK(s) → Build APK(s)**
4. 产物：`app/build/outputs/apk/debug/app-debug.apk`

---

## 方式二：GitHub 云端编译（没装 AS 用这个）

1. 新建一个 GitHub 仓库，把整个 `cainiao_click` 文件夹内容推送上去
2. 仓库 **Actions** 页签 → 自动跑 `Build APK`
3. 跑完在 Artifacts 里下载 `cainiao-click-apk`

没有本地环境，这条路最省事。

---

## 装上去怎么用

1. 装 APK（debug 签名即可）
2. LSPosed 管理器 → 模块 → 启用「菜鸟自动点击」
3. 作用域勾 **菜鸟（com.cainiao.wireless）**
4. **强停菜鸟**，然后重新打开
5. 手动进到裹酱任务页

模块会在页面类名包含 `task` / `guojiang` / `reward` 时自动开始轮询，
每 3 秒扫一次界面，找到按钮就点。

---

## 看效果

```bash
adb logcat | grep FJ-CN
```

正常输出长这样：

```
[FJ-CN] 模块已注入进程
[FJ-CN] 前台页面: HomePageActivity
[FJ-CN] 前台页面: GuojiangTaskActivity
[FJ-CN] === 开始轮询 ===
[FJ-CN] 点击 [去完成] 返回=true 控件=LinearLayout 累计=1
[FJ-CN] 点击 [领取]   返回=true 控件=FrameLayout  累计=2
[FJ-CN] 本页没找到可点的按钮: GuojiangTaskActivity
[FJ-CN] === 收工，共点 2 次 ===
```

不用 adb 也行，LSPosed 的日志页能直接看。

---

## 调参（都在 MainHook.java 顶部）

| 常量 | 默认 | 说明 |
|---|---|---|
| `BTN_WORDS` | 去完成/去逛逛/去浏览/立即领取/领取/做任务/看视频/去观看 | 按钮文字，新版对不上就改这里 |
| `INTERVAL` | 3000 | 每轮间隔，稳一点改 5000 |
| `MAX_CLICK` | 60 | 单次上限，防跑飞 |
| `SAME_VIEW_GAP` | 8000 | 同一控件最短重复间隔，防连点 |

---

## 排查

**LSPosed 里看不到模块**
`assets/xposed_init` 里类名要和实际包名一致：`com.fujiang.cainiao.MainHook`。
文件不能带后缀，不能有 BOM。

**日志里没有「模块已注入进程」**
作用域没勾菜鸟，或者装完没强停菜鸟。强停再开。

**有注入日志，但一直「没找到可点的按钮」**
说明按钮文字不在 `BTN_WORDS` 里。用开发助手/MT 管理器点开那个按钮，看它的 `text` 属性，加进去重装。

**点了但没反应**
有些按钮真正可点的层在更外面。把 `climb()` 里的循环次数 `8` 改到 `12`。

**一直重复点同一个**
`SAME_VIEW_GAP` 调大，或者那个按钮本身点完不变化（说明是无效按钮，从 `BTN_WORDS` 里去掉）。

**模块激活了但菜鸟闪退**
菜鸟有安全检测。LSPosed 里给菜鸟开「隐藏模块」，装 Shamiko 并开启 Zygisk 隐藏。

---

## 安全说明

- 模块不联网、不读文件、不上传任何数据
- 全部逻辑就在 `MainHook.java` 一个文件里，你能逐行看完
- 想停就关开关，或直接在 LSPosed 里禁用
- 建议 `INTERVAL` 别低于 2000，别让节奏太机械
